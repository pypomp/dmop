"""Run one checkpointed Pypomp Bayesian chain; outputs are never overwritten."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
os.environ.setdefault('JAX_ENABLE_X64', 'true')
os.environ.setdefault('XLA_PYTHON_CLIENT_PREALLOCATE', 'false')

import jax
import jax.numpy as jnp
import numpy as np
import pypomp
from model import setup, NAMES, CENTER, SCALE
from kernels import make_kernel, finite_force


def write_json(path, value):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')
    temp.replace(path)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--particles', type=int, default=1000)
    p.add_argument('--alpha', type=float, default=.95)
    p.add_argument('--prior-scale', type=float, default=1.)
    p.add_argument('--method', choices=['mala', 'hmc'], default='mala')
    p.add_argument('--steps', type=int, default=4)
    p.add_argument('--seed', type=int, default=2026101600)
    p.add_argument('--jitter', type=float, default=.04)
    p.add_argument('--optimize', type=int, default=100)
    p.add_argument('--warmup', type=int, default=1000)
    p.add_argument('--draws', type=int, default=2000)
    p.add_argument('--step-size', type=float, default=.01)
    p.add_argument('--checkpoint', type=int, default=25)
    p.add_argument('--initial', type=Path, help='NPY vector in the standardized coordinates')
    a = p.parse_args()
    if min(a.particles,a.steps,a.draws,a.checkpoint,a.step_size,a.prior_scale) <= 0:
        p.error('Counts and scales must be positive')
    a.output.mkdir(parents=True, exist_ok=False)
    source = a.output/'source'
    source.mkdir()
    for f in Path(__file__).parent.glob('*.py'):
        shutil.copy2(f, source/f.name)
    repo = Path(pypomp.__file__).resolve().parents[1]
    cfg = {k:str(v) if isinstance(v,Path) else v for k,v in vars(a).items()}
    cfg.update(utc=datetime.now(timezone.utc).isoformat(), pid=os.getpid(),
               jax=jax.__version__, x64=jax.config.jax_enable_x64,
               devices=[str(x) for x in jax.devices()], affinity=sorted(os.sched_getaffinity(0)),
               pypomp_revision=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
               pypomp_dirty=bool(subprocess.check_output(['git','-C',str(repo),'status','--porcelain'],text=True)),
               source_sha256={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in source.glob('*.py')},
               names=NAMES, prior_center=CENTER.tolist(), prior_sd=(SCALE*a.prior_scale).tolist())
    write_json(a.output/'configuration.json',cfg)
    m = setup(a.particles,a.alpha,a.prior_scale)
    key = jax.random.key(a.seed)
    key, initkey = jax.random.split(key)
    z = (jnp.asarray(np.load(a.initial)) if a.initial else
         jnp.asarray(m['initial']) + a.jitter*jax.random.normal(initkey,(len(NAMES),)))
    np.save(a.output/'initial.npy',np.asarray(z))
    # Warm-start optimization changes only initialization, never the target.
    start = time.monotonic()
    moment, second = jnp.zeros_like(z),jnp.zeros_like(z)
    opt = []
    for i in range(a.optimize):
        key, k = jax.random.split(key)
        val, force = m['value_force'](z,k)
        force = finite_force(force)
        moment=.9*moment+.1*force
        second=.999*second+.001*force**2
        rate=.002*(.1+.9*.5*(1+np.cos(np.pi*i/max(a.optimize,1))))
        z=z+rate*(moment/(1-.9**(i+1)))/(jnp.sqrt(second/(1-.999**(i+1)))+1e-8)
        opt.append(np.r_[float(val),np.asarray(z)])
        if (i+1)%25 == 0:
            np.save(a.output/'optimization.npy',np.asarray(opt))
            print(json.dumps({'phase':'optimization','iteration':i+1,'objective':float(val),
                              'seconds':time.monotonic()-start}),flush=True)
    np.save(a.output/'optimization.npy',np.asarray(opt))
    np.save(a.output/'warm_start.npy',np.asarray(z))
    get_force = lambda z,u: m['value_force'](z,u)[1]
    initialize, kernel = make_kernel(m['loglik'],m['logprior'],get_force,a.method,a.steps)
    key, u = jax.random.split(key)
    state=initialize(z,u)
    if not np.isfinite(float(state.loglik)):
        raise RuntimeError('Initial particle filter collapsed; saved start needs revision')
    chol=jnp.eye(len(NAMES))
    eps=a.step_size
    trace, info, eps_trace, metrics = [],[],[],[]
    target_accept=.57 if a.method=='mala' else .75
    total=a.warmup+a.draws
    for i in range(total):
        key,k=jax.random.split(key)
        state, diagnostics=kernel(state,k,eps,chol)
        diagnostics=np.asarray(diagnostics)
        trace.append(np.r_[float(state.loglik),float(m['logprior'](state.z)),np.asarray(state.z)])
        info.append(diagnostics)
        eps_trace.append(eps)
        if i<a.warmup:
            # Diminishing step adaptation, then freeze all tuning at warmup end.
            eps=float(np.clip(np.exp(np.log(eps)+.3/(1+i/25)**.6*(diagnostics[2]-target_accept)),1e-5,.5))
            # Full covariance estimated from warmup, with a diagonal ridge.
            # Scale to unit mean variance so step adaptation stays continuous.
            if (i+1)%200==0 and i+1<a.warmup and i>=399:
                recent=np.array(trace)[max(0,i//2):,2:]
                covariance=np.cov(recent.T)
                covariance=.9*covariance+.1*np.diag(np.diag(covariance))+1e-5*np.eye(len(NAMES))
                covariance/=np.trace(covariance)/len(NAMES)
                chol=jnp.asarray(np.linalg.cholesky(covariance))
                metrics.append({'iteration':i+1,'chol':np.asarray(chol).tolist()})
        if (i+1)%a.checkpoint==0 or i+1==total:
            tmp=a.output/'checkpoint.tmp.npz'
            np.savez_compressed(tmp,trace=np.array(trace),info=np.array(info),step_size=np.array(eps_trace),
                                z=np.asarray(state.z),u=np.asarray(jax.random.key_data(state.u)),
                                force=np.asarray(state.force),loglik=np.asarray(state.loglik),
                                key=np.asarray(jax.random.key_data(key)),chol=np.asarray(chol),next_step_size=eps)
            tmp.replace(a.output/'checkpoint.npz')
            recent=np.asarray(info)[-a.checkpoint:]
            status={'iteration':i+1,'warmup':a.warmup,'total':total,'complete':i+1==total,
                    'phase':'warmup' if i<a.warmup else 'sampling','seconds':time.monotonic()-start,
                    'loglik':float(state.loglik),'step_size':eps,
                    'parameter_acceptance_recent':float(recent[:,0].mean()),
                    'randomness_acceptance_recent':float(recent[:,1].mean())}
            write_json(a.output/'status.json',status)
            write_json(a.output/'metrics.json',metrics)
            print(json.dumps(status),flush=True)
    write_json(a.output/'completion.json',status)

if __name__=='__main__':
    main()
