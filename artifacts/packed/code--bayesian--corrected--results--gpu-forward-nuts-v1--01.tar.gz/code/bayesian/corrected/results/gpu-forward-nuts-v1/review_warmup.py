"""Inspect the first 50 NUTS warmup updates without treating them as samples."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parents[1]))
from report import COLORS, LABELS, NAMES, style


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-root", type=Path, default=ROOT,
                        help="Run directory containing nuts/chain0 through chain3")
    root = parser.parse_args().run_root.resolve()
    count = 50
    output = root / 'warmup-review-50'
    if output.exists():
        raise ValueError('Review already exists; preserve the frozen snapshot')
    folders = [root / 'nuts' / f'chain{c}' for c in range(4)]
    configs = [json.loads((p / 'configuration.json').read_text()) for p in folders]
    payloads = [(p / 'checkpoint.npz').read_bytes() for p in folders]
    arrays = [np.load(io.BytesIO(b)) for b in payloads]
    if any(len(a['trace']) < count for a in arrays):
        raise ValueError('Wait until all four chains have 50 saved warmup updates')
    for field in ['method', 'warmup', 'names', 'prior_center', 'prior_sd', 'prior_scale']:
        assert all(c[field] == configs[0][field] for c in configs), field
    assert configs[0]['method'] == 'nuts' and configs[0]['warmup'] >= count
    assert len({c['seed'] for c in configs}) == 4
    assert configs[0]['names'] == list(NAMES)
    center = np.asarray(configs[0]['prior_center'])
    scale = np.asarray(configs[0]['prior_sd']) / configs[0]['prior_scale']
    starts = np.stack([np.load(p / 'initial.npy') for p in folders])
    trace = np.stack([a['trace'][:count, 2:] for a in arrays])
    positions = center + np.concatenate([starts[:, None], trace], axis=1) * scale
    info = np.stack([a['info'][:count] for a in arrays])

    # These are descriptive scales from an unconverged run, not truth or a
    # convergence threshold. Keep the reference and its limitations explicit.
    reference = root.parent / 'gpu-comparison-v1' / 'review-pmrw-5000'
    reference_bytes = (reference / 'posterior_draws.npz').read_bytes()
    reference_audit = json.loads((reference / 'audit.json').read_text())
    assert hashlib.sha256(reference_bytes).hexdigest() == reference_audit['draws_sha256']
    assert all(c['source_sha256']['model.py'] == reference_audit['model_sha256'] for c in configs)
    reference_draws = np.load(io.BytesIO(reference_bytes))['draws']
    ref_sd = reference_draws.std(axis=(0, 1))
    assert np.all(ref_sd > 0)
    ref_interval = np.quantile(reference_draws, [.025, .975], axis=(0, 1))
    chains = []
    for c, (a, cfg) in enumerate(zip(arrays, configs)):
        rows = info[c]
        changes = np.diff(positions[c], axis=0)
        chains.append(dict(
            chain=c, checkpoint_sha256=hashlib.sha256(payloads[c]).hexdigest(),
            saved_iterations=len(a['trace']), reviewed_updates=count,
            divergences=int(rows[:, 6].sum()),
            mean_trajectory_acceptance=float(rows[:, 2].mean()),
            randomness_acceptance=float(rows[:, 1].mean()),
            forced_depth_limit_fraction=float(((rows[:, 8] >= cfg['max_depth']) &
                (rows[:, 9] == 0) & (rows[:, 6] == 0)).mean()),
            mean_integration_steps=float(rows[:, 7].mean()),
            step_size_last_reviewed=float(a['step_size'][count-1]),
            median_batch_seconds=float(np.median(a['iteration_seconds'][1:count])),
            movement=[dict(parameter=name,
                rms_jump=float(np.sqrt(np.mean(changes[:, j]**2))),
                rms_jump_over_reference_sd=float(np.sqrt(np.mean(changes[:, j]**2)) / ref_sd[j]),
                range_over_reference_sd=float(np.ptp(positions[c, :, j]) / ref_sd[j]))
                for j, name in enumerate(NAMES)]))
    output.mkdir()
    np.savez_compressed(output / 'warmup_positions.npz', positions=positions, info=info)
    audit = dict(chains=chains, reference=str(reference.relative_to(root.parent)),
        reference_draws_sha256=reference_audit['draws_sha256'],
        reference_retained=reference_audit['retained'],
        reference_numerically_converged=reference_audit['numerical_convergence'],
        interpretation='Warmup movement only. Reference PMMH intervals and SDs are descriptive and unconverged. No posterior convergence or between-method agreement claim.')
    (output / 'audit.json').write_text(json.dumps(audit, indent=2) + '\n')
    render(positions, ref_interval, output)
    print(json.dumps(audit, indent=2))


def render(positions, ref_interval, output):
    """Render from frozen positions so layout fixes do not change the review."""
    count = positions.shape[1] - 1
    plt.rcParams.update({'font.size': 11, 'savefig.dpi': 170})
    fig, axes = plt.subplots(6, 3, figsize=(11, 15), layout='constrained')
    for j, ax in enumerate(axes.flat):
        ax.axhspan(*ref_interval[:, j], color='.5', alpha=.12)
        for c in range(4):
            ax.plot(np.arange(count+1), positions[c, :, j], color=COLORS[c],
                    lw=1.2, label=f'Chain {c+1}')
        ax.set_title(LABELS[j]); style(ax)
    handles, labels = axes.flat[0].get_legend_handles_labels()
    handles.append(Patch(facecolor='.5', alpha=.12))
    labels.append('J5000 PMMH 95% interval (unconverged)')
    fig.legend(handles, labels, loc='outside upper center', ncol=3, frameon=False)
    fig.supxlabel('Warmup update (0 = initial state)')
    fig.savefig(output / 'movement.png')
    plt.close(fig)


if __name__ == '__main__':
    main()
