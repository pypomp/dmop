"""Paired proposal-covariance screen at frozen states; no posterior draws."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))


def main():
    import jax
    import jax.numpy as jnp
    import numpy as np
    import pypomp
    from model import setup
    from force_modes import select_value_force
    from kernels import State
    from nuts import make_nuts_kernel

    p = json.loads((ROOT / 'protocol.json').read_text())
    for directory, hashes in [(ROOT, p['inputs_sha256']), (ROOT / 'source', p['source_sha256'])]:
        for name, digest in hashes.items():
            assert hashlib.sha256((directory / name).read_bytes()).hexdigest() == digest, name
    assert os.environ.get('XLA_FLAGS') == p['xla_flags']
    assert jax.config.jax_enable_x64 and jax.default_backend() == 'gpu'
    assert jax.__version__ == p['jax']
    repo = Path(pypomp.__file__).resolve().parents[1]
    assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == p['pypomp_revision']
    assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True)
    if (ROOT / 'result.json').exists():
        raise ValueError('Preserve existing results; do not duplicate the screen')
    data = np.load(ROOT / 'inputs.npz')
    z, eps = jnp.asarray(data['z']), jnp.asarray(data['step'])
    state = State(z, jax.random.wrap_key_data(jnp.asarray(data['u'])),
                  jnp.asarray(data['loglik']), jnp.asarray(data['force']))
    m = setup(p['particles'], p['alpha'], p['prior_scale'],
              force_particles=p['force_particles'], force_precision=p['force_precision'])
    vf = select_value_force(m['value_force'], p['force_mode'])
    init, kernel = make_nuts_kernel(m['loglik'], m['logprior'],
                                    lambda x, key: vf(x, key)[1], max_depth=p['max_depth'])
    kernel = jax.jit(jax.vmap(kernel))
    result = dict(utc=datetime.now(timezone.utc).isoformat(), complete=False,
                  devices=[str(d) for d in jax.devices()], records=[])

    def save():
        tmp = ROOT / 'result.tmp'
        tmp.write_text(json.dumps(result, indent=2) + '\n')
        tmp.replace(ROOT / 'result.json')

    save()
    start = time.monotonic()
    rebuilt = jax.jit(jax.vmap(init))(state.z, state.u)
    jax.block_until_ready(rebuilt)
    np.testing.assert_array_equal(np.asarray(rebuilt.loglik), data['loglik'])
    np.testing.assert_array_equal(np.asarray(rebuilt.force), data['force'])
    result.update(cache_check_seconds=time.monotonic()-start, cache_matches_bitwise=True)
    save()
    print(json.dumps({'phase': 'cache_verified'}), flush=True)

    def evaluate(candidate, seed, trial, compile_included=False):
        keys = jax.random.split(jax.random.key(seed), len(z))
        chol = jnp.asarray(data[candidate['metric']])
        step = eps * candidate['step_multiplier']
        start = time.monotonic()
        new, info = kernel(state, keys, step, chol)
        jax.block_until_ready((new, info))
        seconds = time.monotonic() - start
        delta = (np.asarray(new.z) - np.asarray(z)) * data['coordinate_scale']
        finite = bool(np.isfinite(np.asarray(new.z)).all() and np.isfinite(np.asarray(new.loglik)).all())
        row = dict(candidate=candidate['name'], seed=seed, trial=trial,
                   compile_included=compile_included, batch_seconds=seconds,
                   finite=finite, info=np.asarray(info).tolist(),
                   squared_jump_over_reference_variance=(delta**2 / data['reference_sd']**2).tolist())
        result['records'].append(row)
        save()
        print(json.dumps({k: row[k] for k in ['candidate', 'trial', 'compile_included', 'batch_seconds', 'finite']}), flush=True)
        if not finite:
            raise ValueError('Nonfinite output; preserve the failure and existing production')

    candidates = p['candidates']
    # One executable is shared by all candidates; covariance and step size
    # are dynamic array arguments with identical shapes and dtypes.
    evaluate(candidates[0], p['compile_seed'], -1, True)
    for trial, seed in enumerate(p['trial_seeds']):
        offset = trial % len(candidates)
        for candidate in candidates[offset:] + candidates[:offset]:
            evaluate(candidate, seed, trial)
    summaries = {}
    for candidate in candidates:
        name = candidate['name']
        records = [r for r in result['records'] if r['candidate'] == name and not r['compile_included']]
        jumps = np.asarray([r['squared_jump_over_reference_variance'] for r in records])
        times = np.asarray([r['batch_seconds'] for r in records])
        infos = np.asarray([r['info'] for r in records])
        rate = jumps.mean(axis=(0, 1)) / times.mean()
        summaries[name] = dict(mean_batch_seconds=float(times.mean()),
            coordinate_jump_rates=rate.tolist(),
            geometric_mean_jump_rate=float(np.exp(np.mean(np.log(rate)))) if np.all(rate > 0) else 0.,
            mean_trajectory_acceptance=float(infos[:, :, 2].mean()),
            divergences=int(infos[:, :, 6].sum()),
            forced_depth_fraction=float(((infos[:, :, 8] >= p['max_depth']) & (infos[:, :, 9] == 0) & (infos[:, :, 6] == 0)).mean()))
    result.update(summaries=summaries, complete=True)
    save()
    print(json.dumps({'phase': 'complete', 'summaries': summaries}), flush=True)


if __name__ == '__main__':
    main()
