"""Paired uncertainty and coordinate losses for the completed metric screen."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
NAMES = ['gamma', 'm', 'epsilon', 'beta_trend', 'sigma', 'tau'] + [f'bs{i}' for i in range(1, 7)] + [f'omegas{i}' for i in range(1, 7)]


def main():
    payload = (ROOT / 'result.json').read_bytes()
    result = json.loads(payload)
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    if not result['complete']:
        raise ValueError('Wait for all paired trials')
    names = [c['name'] for c in protocol['candidates']]
    jumps, seconds, infos, rates = {}, {}, {}, {}
    for name in names:
        rows = sorted([r for r in result['records'] if r['candidate'] == name and not r['compile_included']], key=lambda r: r['trial'])
        assert [r['trial'] for r in rows] == list(range(len(protocol['trial_seeds'])))
        assert [r['seed'] for r in rows] == protocol['trial_seeds']
        assert all(r['finite'] for r in rows)
        jumps[name] = np.asarray([r['squared_jump_over_reference_variance'] for r in rows])
        seconds[name] = np.asarray([r['batch_seconds'] for r in rows])
        infos[name] = np.asarray([r['info'] for r in rows])
        assert jumps[name].shape == (6, 4, 18)
        assert np.isfinite(jumps[name]).all() and np.all(jumps[name] >= 0)
        assert np.isfinite(seconds[name]).all() and np.all(seconds[name] > 0)
        rates[name] = jumps[name].mean(axis=(0, 1)) / seconds[name].mean()
        assert np.all(rates[name] > 0)
    seed, repetitions = 2026111310, 10000
    indices = np.random.default_rng(seed).integers(0, 6, size=(repetitions, 6))
    bootstrap_rates = {name: jumps[name][indices].mean(axis=(1, 2)) /
                       seconds[name][indices].mean(axis=1)[:, None] for name in names}
    comparisons, table = {}, []
    for name in names:
        if name == 'baseline':
            continue
        ratio = rates[name] / rates['baseline']
        overall = float(np.exp(np.log(ratio).mean()))
        expected = result['summaries'][name]['geometric_mean_jump_rate'] / result['summaries']['baseline']['geometric_mean_jump_rate']
        np.testing.assert_allclose(overall, expected, rtol=1e-12)
        with np.errstate(divide='ignore', invalid='ignore'):
            boot_ratio = bootstrap_rates[name] / bootstrap_rates['baseline']
            boot_overall = np.exp(np.log(boot_ratio).mean(axis=1))
        valid = np.isfinite(boot_ratio).all(axis=1) & np.isfinite(boot_overall)
        assert valid.any()
        interval = np.quantile(boot_overall[valid], [.025, .975])
        intervals = np.quantile(boot_ratio[valid], [.025, .975], axis=0)
        gates = dict(point_improvement_at_least_50_percent=overall >= 1.5,
                     mean_acceptance_at_least_half=bool(infos[name][:, :, 2].mean() >= .5),
                     no_divergences=bool(infos[name][:, :, 6].sum() == 0),
                     no_point_loss_bs3_or_omegas5=bool(all(ratio[NAMES.index(n)] >= 1 for n in ['bs3', 'omegas5'])))
        comparisons[name] = dict(geometric_mean_rate_ratio=overall,
            paired_bootstrap_interval=interval.tolist(), undefined_bootstrap_draws=int((~valid).sum()),
            protocol_screen_gates=gates,
            coordinates_with_lower_point_rate=[NAMES[j] for j in np.flatnonzero(ratio < 1)])
        for j, parameter in enumerate(NAMES):
            table.append([name, parameter, rates['baseline'][j], rates[name][j], ratio[j], *intervals[:, j]])
    with (ROOT / 'coordinate_comparison.csv').open('w') as f:
        writer = csv.writer(f)
        writer.writerow(['candidate', 'parameter', 'baseline_rate', 'candidate_rate', 'ratio', 'paired_bootstrap_q025', 'paired_bootstrap_q975'])
        writer.writerows(table)
    summary = dict(result_sha256=hashlib.sha256(payload).hexdigest(),
        paired_trials=6, fixed_states=4, bootstrap_seed=seed, bootstrap_repetitions=repetitions,
        comparisons=comparisons,
        interpretation='Local one-step movement per whole-batch wall time, not ESS/sec or convergence. Resampling preserves each whole paired trial, including all four fixed starting states and shared timing. Intervals do not cover other posterior states, covariance-estimation uncertainty, or hardware workloads. Inspect both candidates and all coordinate losses before any production change; no automatic decision.')
    (ROOT / 'paired_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
