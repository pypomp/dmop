"""Freeze and verify the first two retained updates after NUTS warmup."""
import hashlib,io,json
from pathlib import Path
import numpy as np
root=Path(__file__).resolve().parent
output=root/'warmup-exit-502'
assert not output.exists(), 'Preserve the existing review'
inputs=np.load(root/'inputs/chol.npy')
records=[]
snap={}
for c in range(4):
    folder=root/'nuts'/f'chain{c}'
    payload=(folder/'checkpoint.npz').read_bytes()
    a=np.load(io.BytesIO(payload))
    cfg=json.loads((folder/'configuration.json').read_text())
    assert cfg['method']=='nuts' and cfg['warmup']==500 and cfg['fixed_metric']
    n=len(a['trace'])
    assert n>=502, f'Chain {c}: wait for 502 updates; has {n}'
    assert np.isfinite(a['trace']).all() and np.isfinite(a['force']).all()
    assert np.array_equal(a['chol'],inputs)
    assert json.loads((folder/'metrics.json').read_text())==[]
    assert np.all(a['step_size'][500:]==a['next_step_size'])
    rows=a['info'][:502]
    for name in ['trace','info','step_size','iteration_seconds']:
        snap[f'chain{c}_{name}']=a[name][:502]
    for name in ['chol','next_step_size','force']:
        snap[f'chain{c}_{name}']=a[name]
    records.append(dict(chain=c+1,saved_iterations=n,reviewed_iterations=502,warmup=500,retained_reviewed=2,
        checkpoint_sha256=hashlib.sha256(payload).hexdigest(),finite_states_and_current_force=True,
        covariance_bitwise_matches_input=True,no_covariance_adaptation_records=True,
        step_frozen_for_all_saved_retained_updates=True,frozen_step=float(a['next_step_size']),
        warmup_divergences=int(rows[:500,6].sum()),retained_divergences=int(rows[500:,6].sum()),
        last50_warmup_trajectory_acceptance=float(rows[450:500,2].mean()),
        last50_warmup_randomness_acceptance=float(rows[450:500,1].mean()),
        last50_warmup_forced_depth_limit_fraction=float(((rows[450:500,8]>=cfg['max_depth']) & (rows[450:500,9]==0) & (rows[450:500,6]==0)).mean())))
output.mkdir()
np.savez_compressed(output/'snapshot.npz',**snap)
report=dict(interpretation='Warmup exit and numerical health only. Two retained draws per chain cannot assess posterior convergence or method agreement.',snapshot_sha256=hashlib.sha256((output/'snapshot.npz').read_bytes()).hexdigest(),chains=records)
(output/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
