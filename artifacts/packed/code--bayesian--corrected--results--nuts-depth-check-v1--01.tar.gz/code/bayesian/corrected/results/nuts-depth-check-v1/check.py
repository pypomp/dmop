"""Compare depth 5 and 6 at frozen warmup states; not posterior sampling."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'source'))


def main():
    import jax
    import jax.numpy as jnp
    import numpy as np
    import pypomp
    from model import setup
    from force_modes import select_value_force
    from kernels import State
    from nuts import make_nuts_kernel

    protocol = json.loads((ROOT / 'protocol.json').read_text())
    for name, digest in protocol['inputs_sha256'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    for name, digest in protocol['source_sha256'].items():
        assert hashlib.sha256((ROOT / 'source' / name).read_bytes()).hexdigest() == digest, name
    assert os.environ.get('XLA_FLAGS') == protocol['xla_flags']
    assert jax.config.jax_enable_x64 and jax.default_backend() == 'gpu'
    assert jax.__version__ == protocol['jax']
    repo = Path(pypomp.__file__).resolve().parents[1]
    assert subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip() == protocol['pypomp_revision']
    assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True)
    if (ROOT / 'result.json').exists():
        raise ValueError('Preserve existing results; do not duplicate the benchmark')
    data = np.load(ROOT / 'inputs.npz')
    z, chol, eps = (jnp.asarray(data[k]) for k in ['z', 'chol', 'step'])
    u = jax.random.wrap_key_data(jnp.asarray(data['u']))
    state = State(z, u, jnp.asarray(data['loglik']), jnp.asarray(data['force']))
    m = setup(protocol['particles'], protocol['alpha'], protocol['prior_scale'],
              force_particles=protocol['force_particles'], force_precision='float32')
    vf = select_value_force(m['value_force'], 'forward')
    kernels = {}
    for depth in protocol['depths']:
        _, kernel = make_nuts_kernel(m['loglik'], m['logprior'],
                                     lambda x, key: vf(x, key)[1], max_depth=depth)
        kernels[depth] = jax.jit(jax.vmap(kernel))
    result = dict(utc=datetime.now(timezone.utc).isoformat(), complete=False,
                  devices=[str(d) for d in jax.devices()], records=[])

    def save():
        tmp = ROOT / 'result.tmp'
        tmp.write_text(json.dumps(result, indent=2) + '\n')
        tmp.replace(ROOT / 'result.json')

    save()
    # Check the cached extended state against the exact frozen implementation.
    init, _ = make_nuts_kernel(m['loglik'], m['logprior'], lambda x, key: vf(x, key)[1])
    start = time.monotonic()
    rebuilt = jax.jit(jax.vmap(init))(z, u)
    jax.block_until_ready(rebuilt)
    np.testing.assert_array_equal(np.asarray(rebuilt.loglik), data['loglik'])
    np.testing.assert_array_equal(np.asarray(rebuilt.force), data['force'])
    result['cache_check_seconds'] = time.monotonic() - start
    result['cache_matches_bitwise'] = True
    save()
    print(json.dumps({'phase': 'cache_verified', 'seconds': result['cache_check_seconds']}), flush=True)

    def evaluate(depth, seed, compile_included, trial):
        keys = jax.random.split(jax.random.key(seed), len(z))
        start = time.monotonic()
        new, info = kernels[depth](state, keys, eps, chol)
        jax.block_until_ready((new, info))
        seconds = time.monotonic() - start
        info = np.asarray(info)
        delta = (np.asarray(new.z) - np.asarray(z)) * data['coordinate_scale']
        finite = bool(np.isfinite(np.asarray(new.z)).all() and np.isfinite(np.asarray(new.loglik)).all())
        row = dict(depth=depth, seed=seed, trial=trial, compile_included=compile_included,
                   batch_seconds=seconds, finite=finite, info=info.tolist(),
                   squared_jump_over_reference_variance=(delta**2 / data['reference_sd']**2).tolist())
        result['records'].append(row)
        save()
        print(json.dumps({k: row[k] for k in ['depth', 'trial', 'compile_included', 'batch_seconds', 'finite']}), flush=True)
        if not finite:
            raise ValueError('Nonfinite benchmark output; preserve failure and current production')

    # Compilation has separate keys and is excluded from movement/cost scores.
    for depth in protocol['depths']:
        evaluate(depth, protocol['compile_seed'], True, -1)
    for trial, seed in enumerate(protocol['trial_seeds']):
        for depth in protocol['depths'][::1 if trial % 2 == 0 else -1]:
            evaluate(depth, seed, False, trial)

    summaries = {}
    for depth in protocol['depths']:
        records = [r for r in result['records'] if r['depth'] == depth and not r['compile_included']]
        jumps = np.asarray([r['squared_jump_over_reference_variance'] for r in records])
        times = np.asarray([r['batch_seconds'] for r in records])
        infos = np.asarray([r['info'] for r in records])
        rate = jumps.mean(axis=(0, 1)) / times.mean()
        summaries[str(depth)] = dict(mean_batch_seconds=float(times.mean()),
            coordinate_jump_rates=rate.tolist(),
            geometric_mean_jump_rate=float(np.exp(np.mean(np.log(rate)))) if np.all(rate > 0) else 0.,
            mean_trajectory_acceptance=float(infos[:, :, 2].mean()),
            divergences=int(infos[:, :, 6].sum()),
            forced_depth_fraction=float(((infos[:, :, 8] >= depth) & (infos[:, :, 9] == 0) & (infos[:, :, 6] == 0)).mean()))
    result['summaries'] = summaries
    result['depth6_over_depth5_jump_rate'] = (summaries['6']['geometric_mean_jump_rate'] /
                                            summaries['5']['geometric_mean_jump_rate'])
    result['complete'] = True
    save()
    print(json.dumps({'phase': 'complete', 'summaries': summaries,
                      'depth6_over_depth5_jump_rate': result['depth6_over_depth5_jump_rate']}), flush=True)


if __name__ == '__main__':
    main()
