"""Summarize the completed paired depth screen, including trial variability."""
import csv
import hashlib
import json
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
NAMES = ['gamma', 'm', 'epsilon', 'beta_trend', 'sigma', 'tau'] + [f'bs{i}' for i in range(1, 7)] + [f'omegas{i}' for i in range(1, 7)]


def main():
    payload = (ROOT / 'result.json').read_bytes()
    result = json.loads(payload)
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    if not result['complete']:
        raise ValueError('Wait for all paired transitions')
    jumps, seconds, infos = {}, {}, {}
    for depth in [5, 6]:
        rows = sorted([r for r in result['records'] if r['depth'] == depth and not r['compile_included']], key=lambda r: r['trial'])
        assert [r['trial'] for r in rows] == list(range(len(protocol['trial_seeds'])))
        assert [r['seed'] for r in rows] == protocol['trial_seeds']
        assert all(r['finite'] for r in rows)
        jumps[depth] = np.asarray([r['squared_jump_over_reference_variance'] for r in rows])
        seconds[depth] = np.asarray([r['batch_seconds'] for r in rows])
        infos[depth] = np.asarray([r['info'] for r in rows])
        assert jumps[depth].shape == (6, 4, 18)
        assert np.isfinite(jumps[depth]).all() and np.all(jumps[depth] >= 0)
        assert np.isfinite(seconds[depth]).all() and np.all(seconds[depth] > 0)
    rates = {d: jumps[d].mean(axis=(0, 1)) / seconds[d].mean() for d in [5, 6]}
    assert np.all(rates[5] > 0) and np.all(rates[6] > 0)
    ratio = rates[6] / rates[5]
    overall = float(np.exp(np.log(ratio).mean()))
    np.testing.assert_allclose(overall, result['depth6_over_depth5_jump_rate'], rtol=1e-12)

    # Resample whole paired trials: retain all four fixed starting states and
    # the shared batch timing, and use identical indices for both depths.
    seed, repetitions = 2026111210, 10000
    indices = np.random.default_rng(seed).integers(0, 6, size=(repetitions, 6))
    bootstrap_rates = {d: jumps[d][indices].mean(axis=(1, 2)) /
                       seconds[d][indices].mean(axis=1)[:, None] for d in [5, 6]}
    with np.errstate(divide='ignore', invalid='ignore'):
        bootstrap_ratio = bootstrap_rates[6] / bootstrap_rates[5]
        bootstrap_overall = np.exp(np.log(bootstrap_ratio).mean(axis=1))
    valid = np.isfinite(bootstrap_ratio).all(axis=1) & np.isfinite(bootstrap_overall)
    assert valid.any()
    interval = np.quantile(bootstrap_overall[valid], [.025, .975])
    intervals = np.quantile(bootstrap_ratio[valid], [.025, .975], axis=0)
    with (ROOT / 'coordinate_comparison.csv').open('w') as f:
        writer = csv.writer(f)
        writer.writerow(['parameter', 'depth5_rate', 'depth6_rate', 'ratio', 'paired_bootstrap_q025', 'paired_bootstrap_q975'])
        for j, name in enumerate(NAMES):
            writer.writerow([name, rates[5][j], rates[6][j], ratio[j], *intervals[:, j]])
    gates = dict(point_improvement_at_least_25_percent=overall >= 1.25,
                 candidate_mean_acceptance_at_least_half=bool(infos[6][:, :, 2].mean() >= .5),
                 candidate_no_divergences=bool(infos[6][:, :, 6].sum() == 0))
    summary = dict(result_sha256=hashlib.sha256(payload).hexdigest(),
        paired_trials=6, fixed_states=4, bootstrap_seed=seed, bootstrap_repetitions=repetitions,
        undefined_bootstrap_draws=int((~valid).sum()), geometric_mean_rate_ratio=overall,
        paired_bootstrap_interval=interval.tolist(), protocol_screen_gates=gates,
        coordinates_with_lower_point_rate=[NAMES[j] for j in np.flatnonzero(ratio < 1)],
        interpretation='Local one-step movement per batch wall time, not ESS/sec or convergence. Bootstrap resamples six paired trials at four fixed warmup states; it does not cover uncertainty across posterior states or hardware workloads. Inspect individual-coordinate losses and interval width before changing production; no automatic decision.')
    (ROOT / 'paired_summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
